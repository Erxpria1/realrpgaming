-- #######################################
-- ## Project: Internet radio			##
-- ## Authors: MTA contributors			##
-- ## Version: 1.0						##
-- #######################################

RADIO_BOX_MODEL = 2229
RADIO_DESTROY_ON_VEHICLE_EXPLODE = false
RADIO_DESTROY_ON_VEHICLE_DESTROY = false
RADIO_DESTROY_SPEAKER_COMMAND = "destroyspeaker"
RADIO_DESTROY_SPEAKER_ACCESS_RIGHT = "function.kickPlayer"
RADIO_DESTROY_SPEAKERS_IN_RANGE_COMMAND = "destroyspeakers"
RADIO_DESTROY_SPEAKERS_IN_RANGE_ACCESS_RIGHT = "function.kickPlayer"